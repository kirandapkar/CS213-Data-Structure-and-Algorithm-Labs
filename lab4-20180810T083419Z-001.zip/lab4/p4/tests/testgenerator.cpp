#include"iomanip"
#include"iostream"
#include"limits"
#include"cmath"
#include"vector"
#include"algorithm"
#include"list"
#include"queue"
#include"stack"
#include"set"
#include"unordered_set"
#include"map"
#include"unordered_map"
#include"string"
#include"cstring"
#include"assert.h"
using namespace std;
#define ff first
#define ss second
#define all(v) v.begin(),v.end()
#define mp make_pair
#define pb push_back
#define mset(a,b) memset(a,b,sizeof(a))
typedef long long ll;
typedef long double ld;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n,m;
    cin>>n>>m;
    cout<<n<<' '<<m<<'\n';
    srand(clock());
    for(int i=0;i<m;++i)
    {
        int x1= rand()%n+1;
        int y1= rand()%n+1;
        int x2= rand()%n+1;
        int y2= rand()%n+1;
        char ch = 'w';
        if(x1%2==0)
        {
            ch ='b';
        }
        cout<<x1<<' '<<y1<<' '<<x2<<' '<<y2<<' '<<ch<<" \n";
    }
}
