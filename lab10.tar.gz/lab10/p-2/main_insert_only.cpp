#include "p2.cpp"
using namespace std;

// checks only insert
int main( int argc, char const *argv[] )
{
    node *n = NULL;
    int count;
    cin >> count;
    int temp;
    for ( int i = 0; i < count; i++ )
    {
        cin >> temp;
        n = insert( n, temp );
    }
    printTree( n );
    return 0;
}
