#include <iostream>
using namespace std;

struct node
{
    int data;
    struct node *left;
    struct node *right;
};

/* 
 Given a binary tree, return true ( 1 ) if a node 
 with the target data is found in the tree, otherwise false ( 0 )
*/
int lookup( struct node *node, int target )
{
}

/* 
 Give a binary search tree and a number, inserts a new node 
 with the given number in the correct place in the tree. 
 Returns the new root pointer which the caller should 
 then use (the standard trick to avoid using reference 
 parameters). 
*/
struct node *insert( struct node *node, int data )
{
}

/* Given a binary search tree and a key, this function deletes the key
   and returns the new root */
struct node *deleteNode( struct node *root, int key )
{
}

/* 
 Given a binary search tree, print out 
 its data elements in increasing 
 sorted order. 
*/
void printTree( struct node *node )
{
}
