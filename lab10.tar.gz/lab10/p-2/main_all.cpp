#include "p2.cpp"
using namespace std;

// checks everything - insert, delete, lookup
int main( int argc, char const *argv[] )
{
    node *n = NULL;
    int countI, countD, countS, temp;

    cin >> countI;
    for ( int i = 0; i < countI; i++ )
    {
        cin >> temp;
        n = insert( n, temp );
    }
    printTree( n );

    cin >> countS;
    for ( int i = 0; i < countS; i++ )
    {
        cin >> temp;
        cout << lookup( n, temp ) << endl;
    }

    cin >> countD;
    for ( int i = 0; i < countD; i++ )
    {
        cin >> temp;
        n = deleteNode( n, temp );
    }
    printTree( n );

    return 0;
}
