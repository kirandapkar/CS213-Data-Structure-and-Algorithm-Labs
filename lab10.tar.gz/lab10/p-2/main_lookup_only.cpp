#include "p2.cpp"
using namespace std;

// checks search (and insert)
int main( int argc, char const *argv[] )
{
    node *n = NULL;
    int count, countS;
    cin >> count;
    int temp;
    for ( int i = 0; i < count; i++ )
    {
        cin >> temp;
        n = insert( n, temp );
    }
    cin >> countS;
    for ( int i = 0; i < countS; i++ )
    {
        cin >> temp;
        cout << lookup( n, temp ) << endl;
    }
    return 0;
}
