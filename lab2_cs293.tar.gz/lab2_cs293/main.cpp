#include "LinkedList.cpp"
using namespace std;

int main() {
	LinkedList myList;
	LinkedList mergeList;
	int t1, t2;
	char ch;
	cin >> ch;
	while(ch!='q') {
		// i for insertEnd # i <val>
		// n for insertAtInd  # i <ind> <val>
		// p for print
		// r for reverse
		// d for deleteAll # d <val>
		// c for count
		// m for midValue
		// mergePoint check seperately
		if (ch == 'i') {
			cin >> t1;
			myList.insertEnd(t1);
		} else if (ch == 'n') {
			cin >> t1 >> t2;
			myList.insertAtInd(t1, t2);
		} else if (ch == 'p') {
			myList.print();
		} else if (ch == 'd') {
			cin >> t1;
			myList.deleteAll(t1);
		} else if (ch == 'c') {
			cout << myList.count() << endl;
		}
		cin >> ch;
	}
}
