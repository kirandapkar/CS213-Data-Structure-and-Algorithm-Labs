#include <iostream>
using namespace std;

class LinkedList {
	public:
		
	struct node {
		int data;
		node * next;
	};

	node * head;

	LinkedList(); // Constructor
	~LinkedList(); // Destructor

	void insertEnd(int val); // insert val at the end of List
	bool insertAtInd(int ind,int val); // insert val at index ind
	int count(); // return the total number of elements
	void print(); // print the LinkedList -- Example: 1 2 3 4 
	int deleteAll(int val); // return the number of elements deleted
};
