#include "Polynomial.h"
int main() {
	Polynomial p1,p2;
	p1.read();
	p2.read();
	Polynomial p3 = p1 + p2;
	Polynomial p4 = p1 - p2;
	Polynomial p5 = p1 * p2;
	Polynomial p6 = p1 / p2;
	Polynomial p7 = p1 % p2;
	Polynomial p8 = p2.derivative();
	Polynomial p9 = p2.integral();
	p1.print();
	p2.print();
	p3.print();
	p4.print();
	p5.print();
	p6.print();
	p7.print();
	p8.print();
	p9.print();
	cout << p9.valueAt(-1) << endl;
}
