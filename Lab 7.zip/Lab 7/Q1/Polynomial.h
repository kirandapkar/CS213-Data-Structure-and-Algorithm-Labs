/*You may modify this file as needed but the given methods (lines 12-22) need to be supported as given.
  Don't change the signatures of these mandatory functions in your class design. */

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
class Polynomial{
    double array[101];
    int degree;
public:
    Polynomial ();   // constructor
    void read(); // takes the input of polynomial (first the number of terms and then exponent(s) followed by coefficient(s))
    void print() const; // prints the polynomial in the format (coeff)x^index
    Polynomial operator + (const Polynomial p) const; // overloaded operator for adding 2 polynomials
    Polynomial operator - (const Polynomial p) const; // overloaded operator for subtracting 2 polynomials
    Polynomial operator * (const Polynomial p) const; // overloaded operator for multiplying 2 polynomials
    Polynomial operator / (const Polynomial p) const; // overloaded operator for dividing 2 polynomials(returns quotient)
    Polynomial operator % (const Polynomial p) const; // overloaded operator for dividing 2 polynomials(returns remainder)
    Polynomial derivative() const;// returns the first order derivative of the polynomial
    Polynomial integral() const;// returns the integral of the polynomial wrt x (neglects the constant of integration)
    double valueAt (double x) const; // finds f(x) at a given point
};
