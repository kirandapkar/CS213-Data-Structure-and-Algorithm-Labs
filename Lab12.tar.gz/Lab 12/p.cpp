#include <iostream>  //including anything else not allowed
/*//////////////////////////////////
Do not change anything above this line */


int main(){
	
}
