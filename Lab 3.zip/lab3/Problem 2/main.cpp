#include "LinkedList.h"
using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	int q;
	cin>>q;

	for (int i=0; i<q; i++){
		LinkedList myList1, myList2;
		int n, m, temp;
		cin>>n>>m;
		for (int i = 0; i < n; ++i){
			cin >> temp;
			myList1.insertFront(temp);
		}
		for (int i = 0; i < m; ++i){
			cin >> temp;
			myList2.insertFront(temp);
		}
		myList1.reverse();
		myList2.reverse();
		LinkedList l = add(myList1, myList2);
		l.print();
	}
}