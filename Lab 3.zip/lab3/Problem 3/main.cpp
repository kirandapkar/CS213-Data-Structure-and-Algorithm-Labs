#include"p3.cpp"
using namespace std;
int main()
{
    LinkedList a;
    int n;
    cin>>n;
    for(int i=0;i<n;++i)
    {
        int data;
        cin>>data;
        a.InsertAtFront(data);
    }
    char ch;
    cin>>ch;
    if(ch == 'm')
    {
        LinkedList::node* mid = a.midvalue();
        cout<<(mid->data)<<'\n';
    }
    else if(ch == 'j')
    {
        a.makeCircular();
        int x;
        cin>>x;
        a.nthDelete(x);
        a.print();
    }
}
