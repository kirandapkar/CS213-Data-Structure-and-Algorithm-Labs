#include"LinkedList.h"
using namespace std;

LinkedList::LinkedList()
{
    head = NULL;
}

LinkedList::~LinkedList()
{
    if(head == NULL)
        return;
    if(head == head ->next)
    {
        delete head;
        return;
    }
    node *x = head->next;
    while(x!= NULL)
    {
        node *temp = x->next;
        delete x;
        x = temp;
        if(x == head)
        {
            delete head;
            return;
        }
    }
    delete head;
}

void LinkedList::InsertAtFront(int val)
{
    node *t = new node();
    t->data=val;
    t->next=NULL;
    if(head == NULL)
    {
        head = t;
    }
    else
    {
        node *x = head;
        head = t;
        head->next = x;
    }
}

void LinkedList::print()
{
    node *x = head;
    while(x != NULL)
    {
        cout<<(x->data)<<' ';
        x = x->next;
        if(x == head)
        {
            cout<<endl;
            return;
        }
    }
    cout<<endl;
}

void LinkedList::makeCircular()
{
    if(head == NULL)return;
    node *t=head;
    while(t->next != NULL)
    {
        t = t->next;
        if(t == head)
            return;
    }
    t->next = head;
    return;
}

/*
   Author : Ashutosh Kumar Verma
*/

/*
   Your code---------------------------------
*/

LinkedList::node* LinkedList::midvalue()
{
    ;
}

void LinkedList::nthDelete(int n)
{
    ;
}
