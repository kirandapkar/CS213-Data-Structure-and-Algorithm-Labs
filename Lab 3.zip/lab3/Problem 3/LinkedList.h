#include <iostream>
using namespace std;

class LinkedList {
	public:
	struct node {
		int data;
		node * next;
	};
	node * head;

    LinkedList();
    ~LinkedList();                     //destructor. Also Works for circular lists.
    void InsertAtFront(int val);       //Inserts a node at the beginning of the the list. Not for cicular lists.
    void print();                      //prints the entire list. Workds for circular list too.
    void makeCircular();               //Makes the tail point to the head.

    //to be implemented
    node* midvalue();                  //see problem
    void nthDelete(int n);             //see problem
};
