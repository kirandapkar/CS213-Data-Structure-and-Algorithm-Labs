#include "p3.h"
#include <vector>
#include <iostream>

using namespace std;

/** Initialize your data structure here. Set the size of the deque to be k. */
MyCircularDeque::MyCircularDeque( int k )
{
}

/** Adds an item at the front of Deque. Return true if the operation is successful. */
bool MyCircularDeque::insertFront( int value )
{
}

/** Adds an item at the rear of Deque. Return true if the operation is successful. */
bool MyCircularDeque::insertLast( int value )
{
}

/** Deletes an item from the front of Deque. Return true if the operation is successful. */
bool MyCircularDeque::deleteFront()
{
}

/** Deletes an item from the rear of Deque. Return true if the operation is successful. */
bool MyCircularDeque::deleteLast()
{
}

/** Get the front item from the deque. */
int MyCircularDeque::getFront()
{
}

/** Get the last item from the deque. */
int MyCircularDeque::getRear()
{
}

/** Checks whether the circular deque is empty or not. */
bool MyCircularDeque::isEmpty()
{
}

/** Checks whether the circular deque is full or not. */
bool MyCircularDeque::isFull()
{
}
