#include "p3.h"
#include <iostream>
using namespace std;

int main()
{
    MyCircularDeque* circularDeque = new MyCircularDeque(3); // set the size to be 3
    cout << circularDeque->insertLast(1) << endl;            // return true
    cout << circularDeque->insertLast(2) << endl;            // return true
    cout << circularDeque->insertFront(3) << endl;           // return true
    cout << circularDeque->insertFront(4) << endl;           // return false, the queue is full
    cout << circularDeque->getRear() << endl;                // return 32
    cout << circularDeque->isFull() << endl;                 // return true
    cout << circularDeque->deleteLast() << endl;             // return true
    cout << circularDeque->insertFront(4) << endl;           // return true
    cout << circularDeque->getFront() << endl;               // return 4
}
